to run:

*T.
*RUN ARC

select "Use ZX as Caps Lock/Ctrl" under Input menu
